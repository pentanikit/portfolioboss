<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raquibul Islam - Entrepreneur & Innovator</title>
    <meta name="description" content="Entrepreneur and business innovator specializing in digital transformation, SaaS development, and brand strategy. View my portfolio of successful ventures and achievements.">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <a href="#home" class="brand-link">Raquibul Islam</a>
            </div>
            
            <!-- Desktop Navigation -->
            <div class="nav-menu" id="nav-menu">
                <a href="#home" class="nav-link">Home</a>
                <a href="#about" class="nav-link">About</a>
                <a href="#portfolio" class="nav-link">Portfolio</a>
                <a href="#services" class="nav-link">Services</a>
                <a href="#contact" class="nav-link">Contact</a>
            </div>
            
            <!-- Theme Toggle & Mobile Menu -->
            <div class="nav-actions">
                <button class="theme-toggle" id="theme-toggle" aria-label="Toggle theme">
                    <i class="fas fa-moon" id="theme-icon"></i>
                </button>

                <button class="mobile-menu-toggle" id="mobile-menu-toggle" aria-label="Toggle menu">
                    <i class="fas fa-bars" id="menu-icon"></i>
                </button>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="hero-background">
            <img src="<?php echo e(asset('storage/images/WhatsApp Image 2025-07-07 at 3.44.45 PM.jpeg')); ?>" style="opacity: 0.3;" alt="Entrepreneur workspace" class="hero-image">
            <div class="hero-overlay"></div>
        </div>
        
        <div class="hero-content">
            <div class="hero-text">
                <h1 class="hero-title">
                    <span class="hero-title-line">Hello</span><br>
                    <div class="hero-title-line">I am <span class="hero-title-gradient">Raquibul Islam</span></div> 
                </h1>
                
                <p class="hero-description">
                    Entrepreneur, innovator, and digital transformation expert with 10+ years of experience 
                    building successful ventures and leading high-performance teams.
                </p>
                
                <!-- Stats -->
                <div class="hero-stats">
                    <div class="stat-item">
                        <div class="stat-number">15+</div>
                        <div class="stat-label">Successful Ventures</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">$50M+</div>
                        <div class="stat-label">Revenue Generated</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">200+</div>
                        <div class="stat-label">Team Members Led</div>
                    </div>
                </div>
                
                <!-- CTA Buttons -->
                <div class="hero-actions">
                    <button class="btn btn-primary" onclick="scrollToSection('portfolio')">
                        View My Work
                        <i class="fas fa-arrow-right"></i>
                    </button>
                 
                </div>
            </div>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="scroll-indicator">
            <div class="scroll-mouse">
                <div class="scroll-wheel"></div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <div class="section-header">
               
                <h2 class="section-title">
                    About <span class="gradient-text">Myself</span>
                </h2>
                <p class="section-description">
                   Businessman & Entrepreneur 
                   <br> Passionate about turning innovative ideas into successful businesses that make a real difference in people's lives.
                </p>
            </div>
            
            <div class="about-content">
                <!-- Profile Image -->
                <div class="about-image">
                    <img src="<?php echo e(asset('storage/images/raquibul islam.jpeg')); ?>" alt="Raquibul Islam" class="profile-image">
                </div>
                
                <!-- Content -->
                <div class="about-text">
                    <h3 class="about-heading">Driven by Innovation</h3>
                    <p class="about-paragraph">
                        With over a decade of experience in entrepreneurship and business development, 
                        I've dedicated my career to identifying market opportunities and building solutions 
                        that create lasting value.
                    </p>
                    <p class="about-paragraph">
                        My journey began with a simple belief: technology should serve humanity, not the other way around. 
                        This philosophy has guided me through launching multiple successful ventures, from fintech startups 
                        to e-commerce platforms.
                    </p>
                    <p class="about-paragraph">
                        Today, I focus on helping other entrepreneurs and businesses navigate digital transformation 
                        while building sustainable, profitable enterprises.
                    </p>
                    
                    <!-- Skills -->
                    <div class="skills-section">
                        <h4 class="skills-title">Core Expertise</h4>
                        <div class="skills-list">
                            <span class="skill-tag">Strategic Planning</span>
                            <span class="skill-tag">Digital Transformation</span>
                            <span class="skill-tag">Team Leadership</span>
                            <span class="skill-tag">Product Development</span>
                            <span class="skill-tag">Market Analysis</span>
                            
                            <span class="skill-tag">SaaS Development</span>
                            <span class="skill-tag">Brand Strategy</span>
                            <span class="skill-tag">Operations Management</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Achievements Grid -->
            <div class="achievements-grid">
                <div class="achievement-card">
                    <div class="achievement-icon">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <div class="achievement-value">25+</div>
                    <div class="achievement-label">Awards Won</div>
                </div>
                <div class="achievement-card">
                    <div class="achievement-icon">
                        <i class="fas fa-target"></i>
                    </div>
                    <div class="achievement-value">100%</div>
                    <div class="achievement-label">Goals Achieved</div>
                </div>
                <div class="achievement-card">
                    <div class="achievement-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="achievement-value">50+</div>
                    <div class="achievement-label">Team Size</div>
                </div>
                <div class="achievement-card">
                    <div class="achievement-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="achievement-value">300%</div>
                    <div class="achievement-label">Growth Rate</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Portfolio Section -->
    <section id="portfolio" class="portfolio">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">
                    Featured <span class="gradient-text">Business</span>
                </h2>
                <p class="section-description">
                    A showcase of innovative solutions that have generated millions in revenue and impacted hundreds of thousands of users.
                </p>
            </div>
            
            
            <div class="portfolio-grid">
                <!-- Project 1 -->
                <div class="project-card" onclick="openProjectModal(1)">
                    <div class="project-image">
                        <img src="<?php echo e(asset('storage/images/WhatsApp Image 2024-01-09 at 21.09.55_766bae1f.webp')); ?>" alt="ponnobd">
                        <div class="project-overlay">
                            <!-- <span class="project-category">Ecommerce</span> -->
                            <span class="project-status live">Live</span>
                        </div>
                    </div>
                    <div class="project-content">
                        <h3 class="project-title">Ponnobd</h3>
                        <p class="project-description">
                           Ponnobd Electronics is one of the top electronics, electric and home appliances brand with one of the largest trusted online shop.
                        </p>
                        <!-- <div class="project-technologies">
                            <span class="tech-tag">React Native</span>
                            <span class="tech-tag">Node.js</span>
                            <span class="tech-tag">MongoDB</span>
                            <span class="tech-tag">+1 more</span>
                        </div> -->
                        <div class="project-metrics">$2M+ ARR, 100k+ users</div>
                    </div>
                </div>
                
                <!-- Project 2 -->
                <div class="project-card" onclick="openProjectModal(2)">
                    <div class="project-image">
                        <img src="<?php echo e(asset('storage/images/Pentanik Logo for Social Share.webp')); ?>" alt="">
                        <div class="project-overlay">
                            <!-- <span class="project-category">E-commerce</span> -->
                            <span class="project-status live">Live</span>
                        </div>
                    </div>
                    <div class="project-content">
                        <h3 class="project-title">Pentanik</h3>
                        <p class="project-description">
                           Pentanik has flourished as a prominent brand in Bangladesh's electronics industry by offering a diverse range of high quality electronic products.
                        </p>
                        <!-- <div class="project-technologies">
                            <span class="tech-tag">Next.js</span>
                            <span class="tech-tag">Shopify</span>
                            <span class="tech-tag">Stripe</span>
                            <span class="tech-tag">+1 more</span>
                        </div> -->
                        <div class="project-metrics">$5M+ GMV, 50k+ customers</div>
                    </div>
                </div>
                
                <!-- Project 3 -->
                <div class="project-card" onclick="openProjectModal(3)">
                    <div class="project-image">
                        <img src="<?php echo e(asset('storage/images/logo-onlinebanglanews-raq.jpg')); ?>" alt="Online bangla news">
                        <div class="project-overlay">
                            <!-- <span class="project-category">Media</span> -->
                            <span class="project-status live">Live</span>
                        </div>
                    </div>
                    <div class="project-content">
                        <h3 class="project-title">Online Bangla News</h3>
                        <p class="project-description">
                           দেশ ও জনগনের স্বার্থে
                        </p>
                        <!-- <div class="project-technologies">
                            <span class="tech-tag">React</span>
                            <span class="tech-tag">Python</span>
                            <span class="tech-tag">PostgreSQL</span>
                            <span class="tech-tag">+1 more</span>
                        </div> -->
                        <div class="project-metrics">$10M+ ARR, 500+ enterprises</div>
                    </div>
                </div>
                
                <!-- Project 4 -->
                <div class="project-card" onclick="openProjectModal(4)">
                    <div class="project-image">
                        <img src="<?php echo e(asset('storage/images/logo-pentanikit.jpg')); ?>" alt="pentanikit">
                        <div class="project-overlay">
                            <!-- <span class="project-category">Service</span> -->
                            <span class="project-status live">Live</span>
                        </div>
                    </div>
                    <div class="project-content">
                        <h3 class="project-title">Pentanik IT</h3>
                        <p class="project-description">
                            Pentanik IT Solution Park is your trusted partner for Business Consulting, Business Development, Web Design, and Digital Marketing services.
                        </p>
                        <!-- <div class="project-technologies">
                            <span class="tech-tag">Vue.js</span>
                            <span class="tech-tag">Canvas API</span>
                            <span class="tech-tag">AWS</span>
                            <span class="tech-tag">+1 more</span>
                        </div> -->
                        <div class="project-metrics">10k+ brands created</div>
                    </div>
                </div>

                <!--project 5-->
                <div class="project-card" onclick="openProjectModal(4)">
                    <div class="project-image">
                        <img src="<?php echo e(asset('storage/images/logo-servicebari.jpg')); ?>" alt="Service Bari">
                        <div class="project-overlay">
                            <!-- <span class="project-category">Service</span> -->
                            <span class="project-status live">Live</span>
                        </div>
                    </div>
                    <div class="project-content">
                        <h3 class="project-title">Service Bari</h3>
                        <p class="project-description">
                            সেরা সেবায় বিশ্বাসী
                        </p>
                        <!-- <div class="project-technologies">
                            <span class="tech-tag">Vue.js</span>
                            <span class="tech-tag">Canvas API</span>
                            <span class="tech-tag">AWS</span>
                            <span class="tech-tag">+1 more</span>
                        </div> -->
                        <div class="project-metrics">10k+ brands created</div>
                    </div>
                </div>

                <!--project 6-->
                <div class="project-card" onclick="openProjectModal(4)">
                    <div class="project-image">
                        <img src="<?php echo e(asset('storage/images/images.jpg')); ?>" alt="Service Bari">
                        <div class="project-overlay">
                            <!-- <span class="project-category">Service</span> -->
                            <span class="project-status live">Live</span>
                        </div>
                    </div>
                    <div class="project-content">
                        <h3 class="project-title">The Brain BD</h3>
                        <p class="project-description">
                           Luxury Lifestyle Brand
                        </p>
                        <!-- <div class="project-technologies">
                            <span class="tech-tag">Vue.js</span>
                            <span class="tech-tag">Canvas API</span>
                            <span class="tech-tag">AWS</span>
                            <span class="tech-tag">+1 more</span>
                        </div> -->
                        <div class="project-metrics">10k+ brands created</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

  

    <!-- Services Section -->
    <section id="services" class="services">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">
                    My <span class="gradient-text">Services</span>
                </h2>
                <p class="section-description">
                    Comprehensive solutions to help entrepreneurs and businesses achieve sustainable growth and digital excellence.
                </p>
            </div>
            
            <div class="services-grid">
                <!-- Service 1 -->
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-lightbulb"></i>
                    </div>
                    <h3 class="service-title">Business Strategy</h3>
                    <p class="service-description">
                        Comprehensive business planning, market analysis, and strategic roadmap development to accelerate your growth.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> Market Research</li>
                        <li><i class="fas fa-check"></i> Competitive Analysis</li>
                        <li><i class="fas fa-check"></i> Growth Strategy</li>
                        <li><i class="fas fa-check"></i> Business Model Design</li>
                    </ul>
                    <div class="service-price">Starting at $5,000</div>
                    <button class="btn btn-primary service-btn" onclick="scrollToSection('contact')">
                        Get Started <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <!-- Service 2 -->
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <h3 class="service-title">Startup Launch</h3>
                    <p class="service-description">
                        End-to-end support for launching your startup, from MVP development to market entry and scaling.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> MVP Development</li>
                        <li><i class="fas fa-check"></i> Go-to-Market Strategy</li>
                        <li><i class="fas fa-check"></i> Investor Readiness</li>
                        <li><i class="fas fa-check"></i> Team Building</li>
                    </ul>
                    <div class="service-price">Starting at $15,000</div>
                    <button class="btn btn-primary service-btn" onclick="scrollToSection('contact')">
                        Get Started <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <!-- Service 3 -->
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3 class="service-title">Team Leadership</h3>
                    <p class="service-description">
                        Executive coaching and leadership development to build high-performing teams and organizational culture.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> Leadership Coaching</li>
                        <li><i class="fas fa-check"></i> Team Building</li>
                        <li><i class="fas fa-check"></i> Performance Management</li>
                        <li><i class="fas fa-check"></i> Cultural Development</li>
                    </ul>
                    <div class="service-price">Starting at $3,000</div>
                    <button class="btn btn-primary service-btn" onclick="scrollToSection('contact')">
                        Get Started <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <!-- Service 4 -->
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3 class="service-title">Digital Transformation</h3>
                    <p class="service-description">
                        Modernize your business operations with cutting-edge technology and data-driven decision making.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> Process Automation</li>
                        <li><i class="fas fa-check"></i> Technology Integration</li>
                        <li><i class="fas fa-check"></i> Data Analytics</li>
                        <li><i class="fas fa-check"></i> Digital Strategy</li>
                    </ul>
                    <div class="service-price">Starting at $10,000</div>
                    <button class="btn btn-primary service-btn" onclick="scrollToSection('contact')">
                        Get Started <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <!-- Service 5 -->
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-code"></i>
                    </div>
                    <h3 class="service-title">Product Development</h3>
                    <p class="service-description">
                        Full-stack development services for web and mobile applications, from concept to deployment.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> Web Development</li>
                        <li><i class="fas fa-check"></i> Mobile Apps</li>
                        <li><i class="fas fa-check"></i> API Integration</li>
                        <li><i class="fas fa-check"></i> Cloud Infrastructure</li>
                    </ul>
                    <div class="service-price">Starting at $25,000</div>
                    <button class="btn btn-primary service-btn" onclick="scrollToSection('contact')">
                        Get Started <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <!-- Service 6 -->
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-palette"></i>
                    </div>
                    <h3 class="service-title">Brand Strategy</h3>
                    <p class="service-description">
                        Complete brand development including identity design, messaging, and marketing strategy.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> Brand Identity</li>
                        <li><i class="fas fa-check"></i> Marketing Strategy</li>
                        <li><i class="fas fa-check"></i> Content Creation</li>
                        <li><i class="fas fa-check"></i> Brand Guidelines</li>
                    </ul>
                    <div class="service-price">Starting at $8,000</div>
                    <button class="btn btn-primary service-btn" onclick="scrollToSection('contact')">
                        Get Started <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </div>
            
            <!-- Call to Action -->
            <div class="services-cta">
                <h3 class="cta-title">Ready to Transform Your Business?</h3>
                <p class="cta-description">
                    Let's discuss how we can work together to achieve your goals and take your business to the next level.
                </p>
                <div class="cta-buttons">
                    <button class="btn btn-primary" onclick="scrollToSection('contact')">
                        Schedule a Consultation
                    </button>
                    <button class="btn btn-outline" onclick="scrollToSection('portfolio')">
                        View Portfolio
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">
                    Let's Work <span class="gradient-text">Together</span>
                </h2>
                <p class="section-description">
                    Ready to turn your vision into reality? Get in touch and let's discuss how we can create something amazing together.
                </p>
            </div>
            
            <div class="contact-content">
                <!-- Contact Form -->
                <div class="contact-form-wrapper">
                    <div class="contact-form-card">
                        <h3 class="form-title">Send a Message</h3>
                        <form id="contact-form" class="contact-form">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="name">Full Name *</label>
                                    <input type="text" id="name" name="name" required placeholder="John Doe">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email Address *</label>
                                    <input type="email" id="email" name="email" required placeholder="john@company.com">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="company">Company</label>
                                    <input type="text" id="company" name="company" placeholder="Your Company">
                                </div>
                                <div class="form-group">
                                    <label for="subject">Subject *</label>
                                    <input type="text" id="subject" name="subject" required placeholder="Project Discussion">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Budget Range</label>
                                    <div class="budget-options">
                                        <span class="budget-option" data-budget="$5k - $15k">$5k - $15k</span>
                                        <span class="budget-option" data-budget="$15k - $50k">$15k - $50k</span>
                                        <span class="budget-option" data-budget="$50k - $100k">$50k - $100k</span>
                                        <span class="budget-option" data-budget="$100k+">$100k+</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Timeline</label>
                                    <div class="timeline-options">
                                        <span class="timeline-option" data-timeline="ASAP">ASAP</span>
                                        <span class="timeline-option" data-timeline="1-3 months">1-3 months</span>
                                        <span class="timeline-option" data-timeline="3-6 months">3-6 months</span>
                                        <span class="timeline-option" data-timeline="6+ months">6+ months</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="message">Message *</label>
                                <textarea id="message" name="message" required rows="5" placeholder="Tell me about your project, goals, and how I can help..."></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary form-submit">
                                <span class="submit-text">Send Message</span>
                                <span class="submit-loading" style="display: none;">
                                    <i class="fas fa-spinner fa-spin"></i> Sending...
                                </span>
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Contact Information -->
                <div class="contact-info">
                    <div class="contact-info-card">
                        <h3 class="info-title">Contact Information</h3>
                        <div class="info-items">
                            <div class="info-item" onclick="window.location.href='mailto:alex@alexthompson.com'">
                                <div class="info-icon">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Email</div>
                                    <div class="info-value">alex@alexthompson.com</div>
                                </div>
                            </div>
                            <div class="info-item" onclick="window.location.href='tel:+15551234567'">
                                <div class="info-icon">
                                    <i class="fas fa-phone"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Phone</div>
                                    <div class="info-value">+1 (555) 123-4567</div>
                                </div>
                            </div>
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Location</div>
                                    <div class="info-value">San Francisco, CA</div>
                                </div>
                            </div>
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Response Time</div>
                                    <div class="info-value">Within 24 hours</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="contact-info-card">
                        <h3 class="info-title">
                            <i class="fas fa-calendar-alt"></i>
                            Schedule a Call
                        </h3>
                        <p class="info-description">
                            Prefer to talk? Schedule a 30-minute consultation call to discuss your project in detail.
                        </p>
                        <button class="btn btn-outline" onclick="scheduleCall()">
                            <i class="fas fa-calendar-alt"></i>
                            Book a Call
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <!-- Brand -->
                <div class="footer-brand">
                    <div class="footer-logo">Alex Thompson</div>
                    <p class="footer-description">
                        Entrepreneur and digital transformation expert helping businesses turn innovative ideas into successful ventures.
                    </p>
                    <div class="social-links">
                        <a href="#" class="social-link" onclick="handleSocialClick('Twitter')">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="social-link" onclick="handleSocialClick('LinkedIn')">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="#" class="social-link" onclick="handleSocialClick('GitHub')">
                            <i class="fab fa-github"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div class="footer-section">
                    <h4 class="footer-section-title">Quick Links</h4>
                    <div class="footer-links">
                        <a href="#home" class="footer-link">Home</a>
                        <a href="#about" class="footer-link">About</a>
                        <a href="#portfolio" class="footer-link">Portfolio</a>
                        <a href="#services" class="footer-link">Services</a>
                        <a href="#contact" class="footer-link">Contact</a>
                    </div>
                </div>
                
                <!-- Contact Info -->
                <div class="footer-section">
                    <h4 class="footer-section-title">Get in Touch</h4>
                    <div class="footer-contact">
                        <a href="mailto:alex@alexthompson.com" class="footer-contact-item">
                            <i class="fas fa-envelope"></i>
                            alex@alexthompson.com
                        </a>
                        <a href="tel:+15551234567" class="footer-contact-item">
                            <i class="fas fa-phone"></i>
                            +1 (555) 123-4567
                        </a>
                        <div class="footer-contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            San Francisco, CA
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Bottom Bar -->
            <div class="footer-bottom">
                <div class="footer-bottom-content">
                    <div class="footer-copyright">
                        © 2024 Alex Thompson. All rights reserved.
                    </div>
                    <div class="footer-bottom-links">
                        <a href="#" class="footer-bottom-link" onclick="showPrivacyPolicy()">Privacy Policy</a>
                        <a href="#" class="footer-bottom-link" onclick="showTerms()">Terms of Service</a>
                        <button class="btn btn-outline btn-small" onclick="scrollToTop()">
                            <i class="fas fa-arrow-up"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Project Modal -->
    <div id="project-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modal-title" class="modal-title"></h2>
                <button class="modal-close" onclick="closeProjectModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <img id="modal-image" class="modal-image" src="" alt="">
                <div class="modal-details">
                    <div class="modal-description">
                        <h4>Project Details</h4>
                        <p id="modal-long-description"></p>
                        <div class="modal-info">
                            <div><strong>Category:</strong> <span id="modal-category"></span></div>
                            <div><strong>Status:</strong> <span id="modal-status"></span></div>
                            <div><strong>Metrics:</strong> <span id="modal-metrics"></span></div>
                        </div>
                    </div>
                    <div class="modal-technologies">
                        <h4>Technologies Used</h4>
                        <div id="modal-tech-list" class="tech-tags"></div>
                        
                        <h4>Key Achievements</h4>
                        <ul id="modal-achievements" class="achievement-list"></ul>
                    </div>
                </div>
                <div class="modal-actions">
                    <button class="btn btn-primary" onclick="viewLive()">
                        <i class="fas fa-external-link-alt"></i>
                        View Live
                    </button>
                    <button class="btn btn-outline" onclick="viewCode()">
                        <i class="fab fa-github"></i>
                        View Code
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <div class="toast-content">
            <i class="fas fa-check-circle"></i>
            <span id="toast-message">Message sent successfully!</span>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="./js/app.js"></script>
</body>
</html><?php /**PATH C:\Users\Pentanik IT\Desktop\portfolioboss\resources\views/welcome.blade.php ENDPATH**/ ?>